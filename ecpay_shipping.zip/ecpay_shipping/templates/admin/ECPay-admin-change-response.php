<?php
/**
 * 後台 - 訂單變更門市
 */

defined('ECPAY_PLUGIN_PATH') || exit;

?>
<script type="text/javascript">

    alert('門市已變更完成');
    window.close();

    // 重新整理頁面
    window.opener.location.reload(false);
</script>